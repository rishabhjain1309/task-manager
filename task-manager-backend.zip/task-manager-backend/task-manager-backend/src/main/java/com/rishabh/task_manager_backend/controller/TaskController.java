package com.rishabh.task_manager_backend.controller;

import com.rishabh.task_manager_backend.dto.TaskRequest;
import com.rishabh.task_manager_backend.dto.TaskResponse;
import com.rishabh.task_manager_backend.model.Task;
import com.rishabh.task_manager_backend.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @PostMapping
    public TaskResponse createTask(@RequestBody TaskRequest request, Authentication authentication) {
        String username = authentication.getName();
        return taskService.createTask(username, request);
    }

    @GetMapping
    public List<TaskResponse> getAllTasks(Authentication authentication) {
        String username = authentication.getName();
        return taskService.getAllTasks(username);
    }

    @GetMapping("/{id}")
    public TaskResponse getTaskById(@PathVariable Long id, Authentication authentication) {
        String username = authentication.getName();
        return taskService.getTaskById(username, id);
    }

    @PutMapping("/{id}")
    public TaskResponse updateTask(@PathVariable Long id, @RequestBody TaskRequest request, Authentication authentication) {
        String username = authentication.getName();
        return taskService.updateTask(username, id, request);
    }

    @DeleteMapping("/{id}")
    public void deleteTask(@PathVariable Long id, Authentication authentication) {
        String username = authentication.getName();
        taskService.deleteTask(username, id);
    }

    @GetMapping("/category/{category}")
    public List<TaskResponse> getTasksByCategory(@PathVariable String category, Authentication authentication) {
        String username = authentication.getName();
        return taskService.getTasksByCategory(username, category);
    }

    @GetMapping("/status/{completed}")
    public List<TaskResponse> getTasksByCompletion(@PathVariable boolean completed, Authentication authentication) {
        String username = authentication.getName();
        return taskService.getTasksByCompletion(username, completed);
    }

    @GetMapping("/search")
    public List<TaskResponse> searchTasks(@RequestParam String title, Authentication authentication) {
        String username = authentication.getName();
        return taskService.searchTasksByTitle(username, title);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Task> markTaskAsComplete(@PathVariable Long id, @RequestBody TaskRequest request) {
        Task task = taskService.markTaskAsComplete(id, request.isCompleted());
        return ResponseEntity.ok(task); // Ensure this returns the updated task
    }
}