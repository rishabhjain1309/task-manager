package com.rishabh.task_manager_backend.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class TaskResponse {
    private Long id;
    private String title;
    private String description;
    private String category;
    private boolean completed;
    private String priority;
    private LocalDate dueDate;
}
