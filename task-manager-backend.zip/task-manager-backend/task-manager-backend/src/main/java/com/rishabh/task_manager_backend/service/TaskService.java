package com.rishabh.task_manager_backend.service;

import com.rishabh.task_manager_backend.dto.TaskRequest;
import com.rishabh.task_manager_backend.dto.TaskResponse;
import com.rishabh.task_manager_backend.model.Task;

import java.util.List;

public interface TaskService {
    TaskResponse createTask(String username, TaskRequest request);
    List<TaskResponse> getAllTasks(String username);
    TaskResponse getTaskById(String username, Long id);
    TaskResponse updateTask(String username, Long id, TaskRequest request);
    void deleteTask(String username, Long id);
    List<TaskResponse> getTasksByCategory(String username, String category);
    List<TaskResponse> getTasksByCompletion(String username, boolean completed);
    List<TaskResponse> searchTasksByTitle(String username, String title);
    Task markTaskAsComplete(Long id, boolean completed); // Add this
}