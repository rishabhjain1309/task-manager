package com.rishabh.task_manager_backend.service;

import com.rishabh.task_manager_backend.dto.RegisterRequest;
import com.rishabh.task_manager_backend.model.User;
import com.rishabh.task_manager_backend.repository.UserRepository;
import com.rishabh.task_manager_backend.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final UserDetailsService userDetailsService;

    public String register(RegisterRequest request) {
        System.out.println("Processing registration for username: " + request.getUsername());
        try {
            if (userRepository.existsByUsername(request.getUsername())) {
                throw new RuntimeException("Username already exists");
            }

            User user = User.builder()
                    .username(request.getUsername())
                    .email(request.getEmail())
                    .password(passwordEncoder.encode(request.getPassword()))
                    .role(User.Role.USER) // Set default role
                    .build();

            userRepository.save(user);
            System.out.println("User saved to database: " + request.getUsername());
            UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
            String token = jwtUtil.generateToken(userDetails);
            System.out.println("Token generated successfully for username: " + request.getUsername());
            return token;
        } catch (Exception e) {
            System.out.println("Registration error for username " + request.getUsername() + ": " + e.getMessage());
            throw e;
        }
    }

    public String login(String username, String password) {
        System.out.println("Processing login for username: " + username);
        User user = userRepository.findByUsername(username).orElse(null);
        if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
            System.out.println("Login failed for username: " + username + " - Invalid credentials");
            return null;
        }
        UserDetails userDetails = userDetailsService.loadUserByUsername(username);
        String token = jwtUtil.generateToken(userDetails);
        System.out.println("Login successful for username: " + username);
        return token;
    }
}