package com.rishabh.task_manager_backend.repository;

import com.rishabh.task_manager_backend.model.Task;
import com.rishabh.task_manager_backend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByUser(User user);
    List<Task> findByUserAndCategory(User user, String category);
    List<Task> findByUserAndCompleted(User user, boolean completed);
    List<Task> findByUserAndTitleContainingIgnoreCase(User user, String title);
}