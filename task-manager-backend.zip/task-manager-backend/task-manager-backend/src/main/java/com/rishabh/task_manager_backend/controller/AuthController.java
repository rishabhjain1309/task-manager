package com.rishabh.task_manager_backend.controller;

import com.rishabh.task_manager_backend.dto.AuthRequest;
import com.rishabh.task_manager_backend.dto.AuthResponse;
import com.rishabh.task_manager_backend.dto.RegisterRequest;
import com.rishabh.task_manager_backend.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@RequestBody RegisterRequest request) {
        System.out.println("Received register request: " + request);
        try {
            String token = authService.register(request);
            System.out.println("Registration successful for username: " + request.getUsername());
            return ResponseEntity.ok(new AuthResponse(token, request.getUsername()));
        } catch (Exception e) {
            System.out.println("Controller error for username " + request.getUsername() + ": " + e.getMessage());
            return ResponseEntity.badRequest().body(new AuthResponse(null, "Registration failed: " + e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest authRequest) {
        System.out.println("Received login request for username: " + authRequest.getUsername());
        String token = authService.login(authRequest.getUsername(), authRequest.getPassword());
        if (token == null) {
            System.out.println("Login failed for username: " + authRequest.getUsername());
            return ResponseEntity.status(401).body(new AuthResponse(null, "Invalid credentials"));
        }
        System.out.println("Login successful for username: " + authRequest.getUsername());
        return ResponseEntity.ok(new AuthResponse(token, authRequest.getUsername()));
    }
}