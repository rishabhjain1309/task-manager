package com.rishabh.task_manager_backend.service;

import com.rishabh.task_manager_backend.dto.TaskRequest;
import com.rishabh.task_manager_backend.dto.TaskResponse;
import com.rishabh.task_manager_backend.model.Task;
import com.rishabh.task_manager_backend.model.User;
import com.rishabh.task_manager_backend.repository.TaskRepository;
import com.rishabh.task_manager_backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
public class TaskServiceImpl implements TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public TaskResponse createTask(String username, TaskRequest request) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new NoSuchElementException("User not found"));

        Task task = new Task();
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setCategory(request.getCategory());
        task.setCompleted(request.isCompleted());
        task.setPriority(request.getPriority());
        task.setDueDate(request.getDueDate());
        task.setUser(user);

        Task savedTask = taskRepository.save(task);
        return convertToResponse(savedTask);
    }

    @Override
    public List<TaskResponse> getAllTasks(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        return taskRepository.findByUser(user)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public TaskResponse getTaskById(String username, Long id) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Task not found"));
        if (!task.getUser().getId().equals(user.getId())) {
            throw new SecurityException("Unauthorized access to task");
        }
        return convertToResponse(task);
    }

    @Override
    public TaskResponse updateTask(String username, Long id, TaskRequest request) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Task not found"));
        if (!task.getUser().getId().equals(user.getId())) {
            throw new SecurityException("Unauthorized access to task");
        }
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setCategory(request.getCategory());
        task.setCompleted(request.isCompleted());
        task.setPriority(request.getPriority());
        task.setDueDate(request.getDueDate());
        Task updated = taskRepository.save(task);
        return convertToResponse(updated);
    }

    @Override
    public void deleteTask(String username, Long id) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Task not found"));
        if (!task.getUser().getId().equals(user.getId())) {
            throw new SecurityException("Unauthorized access to task");
        }
        taskRepository.delete(task);
    }

    @Override
    public List<TaskResponse> getTasksByCategory(String username, String category) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        return taskRepository.findByUserAndCategory(user, category)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<TaskResponse> getTasksByCompletion(String username, boolean completed) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        return taskRepository.findByUserAndCompleted(user, completed)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<TaskResponse> searchTasksByTitle(String username, String title) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        return taskRepository.findByUserAndTitleContainingIgnoreCase(user, title)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    private TaskResponse convertToResponse(Task task) {
        TaskResponse response = new TaskResponse();
        response.setId(task.getId());
        response.setTitle(task.getTitle());
        response.setDescription(task.getDescription());
        response.setCategory(task.getCategory());
        response.setCompleted(task.isCompleted());
        response.setPriority(task.getPriority());
        response.setDueDate(task.getDueDate());
        return response;
    }

    @Override
    public Task markTaskAsComplete(Long id, boolean completed) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Task not found"));
        task.setCompleted(completed);
        return taskRepository.save(task);
    }
}