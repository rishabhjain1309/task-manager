package com.rishabh.task_manager_backend.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class TaskRequest {
    private String title;
    private String description;
    private String category;
    private boolean completed;
    private String priority;
    private LocalDate dueDate;
}
