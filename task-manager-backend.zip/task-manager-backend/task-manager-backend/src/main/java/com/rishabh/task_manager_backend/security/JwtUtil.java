package com.rishabh.task_manager_backend.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Pattern;

@Component
public class JwtUtil {

    // Generate a secure base64-encoded key (replace with a random 32+ byte key in production)
    private static final String SECRET_KEY = Base64.getEncoder().encodeToString("your-very-secure-secret-key-1234567890abcdef".getBytes());
    private static final long JWT_TOKEN_VALIDITY = 5 * 60 * 60 * 1000; // 5 hours in milliseconds

    private static final Pattern SPECIAL_CHAR_PATTERN = Pattern.compile("[^a-zA-Z0-9]");

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    private Claims extractAllClaims(String token) {
        try {
            System.out.println("Extracting claims from token: " + token);
            return Jwts.parserBuilder()
                    .setSigningKey(SECRET_KEY.getBytes()) // Use bytes for signing key
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
        } catch (Exception e) {
            System.out.println("Error extracting claims from token: " + e.getMessage());
            throw e;
        }
    }

    private Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    public String generateToken(UserDetails userDetails) {
        Map<String, Object> claims = new HashMap<>();
        String username = userDetails.getUsername();
        System.out.println("Generating token for raw username: " + username);

        String sanitizedUsername = SPECIAL_CHAR_PATTERN.matcher(username).replaceAll("");
        System.out.println("Sanitized username for token: " + sanitizedUsername);

        try {
            System.out.println("Building token with subject: " + sanitizedUsername);
            String token = Jwts.builder()
                    .setClaims(claims)
                    .setSubject(sanitizedUsername)
                    .setIssuedAt(new Date())
                    .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY))
                    .signWith(SignatureAlgorithm.HS256, SECRET_KEY.getBytes()) // Use bytes for signing
                    .compact();
            System.out.println("Token generated successfully: " + token);
            return token;
        } catch (Exception e) {
            System.out.println("Token generation failed at compact() for username " + username + ": " + e.getMessage());
            throw new RuntimeException("Token generation failed: " + e.getMessage());
        }
    }

    public Boolean validateToken(String token, UserDetails userDetails) {
        try {
            final String username = extractUsername(token);
            System.out.println("Validating token for username: " + username);
            return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
        } catch (Exception e) {
            System.out.println("Token validation error for username " + userDetails.getUsername() + ": " + e.getMessage());
            return false;
        }
    }
}